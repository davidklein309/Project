package edu.pcc.cis233j.countries;

import java.util.List;

/**
 * Read from the Country database and print data on the countries
 * @author Cara Tang & David Klein
 * date 2021.10.31
 *
 * added country database print
 * added a nested for each loop in main for countries
 * delated Country firstCountry = countries.get(0) method
 *
 *
 * added system out print for ID
 *
 */
public class Main {
	public static void main(String[] args) {
		System.out.println("Country Database:");
		CountryDB cdb = new CountryDB();
		List<Country> countries = cdb.readCountries();
		for (Country country : countries) {
			System.out.println("ID: " + country.getId() +
					", Name: " + country.getName() +
					",  Population: " + country.getPopulation() +
					",  Median Age: " + country.getMedianAge() +
					",  Coastline: " + country.getCoastlineKm() + "km" + ",  Languages: " + country.getLanguages());

			}
		}
}

